#1. feladat

n=int(input("Adj meg egy számot 5 és 20 között: "))

vonal="|"
csik="-"
atlo="\\"
plusz="+"
szokoz=" "

if 5<=n<=20:
    print(plusz, (csik*(n-2)), plusz)
    for i in range(n-2):
        print(vonal, (szokoz*(n-2)), vonal, "\n")

    print(plusz, (csik*(n-2)), plusz)
else:
    print("hibás szám")





#2. feladat

ipcim=input("adj meg egy IP címet: ")

oktettarray=ipcim.split(".")

joazertek=False

for elem in oktettarray:
    if 0<=int(elem) and int(elem)<=255:
        joazertek=True
    else:
        joazertek=False

if oktettarray[0]=="0":
        joazertek=False

for elem in oktettarray:
    if elem.startswith("0") and len(elem) > 1:
        joazertek = False

if(joazertek):
    print("jó az ip cím formátum:", ipcim)
else:
    print("hibás formátum")

"""
#3. feladat
t1x=int(input("első téglalap kezdőpozíció x koordináta: "))
t1y=int(input("első téglalap kezdőpozíció y koordináta: "))
t2x=int(input("második téglalap kezdőpozíció x koordináta: "))
t2y=int(input("második téglalap kezdőpozíció y koordináta: "))
t3x=int(input("harmadik téglalap kezdőpozíció x koordináta: "))
t3y=int(input("harmadik téglalap kezdőpozíció y koordináta: "))

t1a=int(input("első téglalap a oldal: "))
t1b=int(input("első téglalap b oldal: "))
t2a=int(input("második téglalap a oldal: "))
t2b=int(input("második téglalap b oldal: "))
t3a=int(input("harmadik téglalap a oldal: "))
t3b=int(input("harmadik téglalap b oldal: "))

szokoz=" "
vonal="|"
csik="_"
"""

#4. feladat

def osztoszamlalo(x):
    osztokszama=0
    i=1
    while i<=x/2:
        if x%i==0:
            osztokszama+=1
        i+=1
    return osztokszama
    
evszamok7tel=[]
szulev=0

for elem in range(1900, 2015):
    if "7" in str(elem) and osztoszamlalo(elem)==8:
        szulev=elem
        
     
    
print("A kapitány ennyi éves: ", 2023-szulev)

#5. feladat
ikerprimarray=[]

for i in range(2,1000):
    j=i+2
    ikerprim=True
    if i%2==0 or i%3==0 or i%5==0 or i%7==0:
        ikerprim=False
    if j%2==0 or j%3==0 or j%5==0 or j%7==0:
        ikerprim=False
    if i==3 or i==5 or j==5:
        ikerprim=True
    if ikerprim==True:
        
        ikerprimarray.append(str(i))
        ikerprimarray.append(str(j))

print("a 60. ker prím pár:\t")
print(ikerprimarray[60], ikerprimarray[61])
    







