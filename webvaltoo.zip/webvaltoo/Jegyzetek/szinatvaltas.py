A=[5,3,6,1,2,4]

A.sort()

print(A)