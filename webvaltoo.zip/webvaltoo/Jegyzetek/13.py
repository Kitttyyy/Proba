def fuggveny(oldalhossz):
    return oldalhossz**2

oldalhosszA=4
oldalhosszB=5
teruletA=fuggveny(oldalhosszA)
teruletB=oldalhosszB**2



print(teruletA, teruletB)