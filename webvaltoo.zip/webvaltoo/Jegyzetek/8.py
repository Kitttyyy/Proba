num=int(input("Adj meg egy számot: "))

if num%2==0:
    print("páros")
else:
    print("páratlan")
    