try:
    szam1=10
    szam2=2

    eredmeny=szam1/szam2

    print(eredmeny)
except ZeroDivisionError:
    print("Hiba, 0-val osztottál!")



