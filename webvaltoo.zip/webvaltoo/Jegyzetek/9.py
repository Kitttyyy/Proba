n=int(input("Adj meg egy számot 3 és 12 között: "))

s="*"

for i in range(0, n):
    print(s)
    s+="*"