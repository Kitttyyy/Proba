n=int(input("Adj meg egy számot 3 és 12 között: "))

spaces= " " * (n-1)
stars="*"

for i in range(1,n+1):
    print(spaces + stars)
    spaces=" " * (n-1-i)
    stars +="*"