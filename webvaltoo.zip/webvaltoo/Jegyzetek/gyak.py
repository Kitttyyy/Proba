nev=input("Add meg a nevedet: ")
kor=int(input("Add meg a korodat: "))
szul_ev=2023-kor

print("Neved:", nev,  "Korod:", kor)
print("Születési éved:", szul_ev)