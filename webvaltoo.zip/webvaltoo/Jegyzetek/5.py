import math
radius =float(input("Add meg a kör sugarát: "))

K= 2*radius*math.pi

T=math.pi * math.pow(radius, 2)

print(f"A kör kerülete: {K} cm, területe: {T} cm2")

