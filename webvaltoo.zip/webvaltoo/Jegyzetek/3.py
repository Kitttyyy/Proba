city_country=( ("Budapest", "Magyarország") , ("Berlin", "Németország") , ("Párizs", "Franciaország"), ("Tokió", "Japán") )
#tapple

city=input("Add meg a város nevét: ")
print(len(city_country))

found=None

for x,y in city_country:
    if city==x:
        found=y
        break

if found:
    print("A ", city, "-hez tartozó ország a: " , found)