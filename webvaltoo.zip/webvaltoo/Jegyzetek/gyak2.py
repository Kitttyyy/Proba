honapok=["január","február","március","április","május","június","július","augusztus","szeptember","október","november","december"]

bekertszam=int(input("Add meg egy hónap sorszámát(1-12): "))

if 1<=bekertszam <=12:
    print("A ", bekertszam,". hónap az a", honapok[bekertszam-1])
if bekertszam==5:
    print("a legjobb hónap")
else:
    print("retardált vagy")




