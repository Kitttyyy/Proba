szamok=[69, 23, 77, 13, 10, 7, 8, 43, 2, 10]

minimum=min(szamok)
maximum=max(szamok)
osszeg=sum(szamok)
atlag=osszeg/len(szamok)

print(f"{minimum}, {maximum}, {osszeg}, {atlag}")