a=int(input("Háromszög a oldala: "))
b=int(input("Háromszög b oldala: "))
c=int(input("Háromszög c oldala: "))

if a+b<=c or b+c<=a or a+c<=b:
    print("nem lehet háromszöget alkotni belőlük")
else:
    print("lehet háromszöget alkotni belőlük")