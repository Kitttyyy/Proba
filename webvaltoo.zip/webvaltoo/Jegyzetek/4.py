#dictionary
products={"alma": 100, 
          "banán": 120, 
          "szőlő":650, 
          "keksz":350
          }

bekertproduct=input("Add meg a termék nevét: ")

if bekertproduct in products:
    ar=products[bekertproduct]
    print(f"{bekertproduct} ára: {ar} Forint")